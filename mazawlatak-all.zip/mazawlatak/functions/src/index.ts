import { onCall, HttpsError, CallableRequest } from "firebase-functions/v2/https";
import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";

initializeApp();
const db = getFirestore();
const opts = { region: "europe-west1" };

const uid = (r: CallableRequest): string => {
  if (!r.auth) throw new HttpsError("unauthenticated", "سجّل الدخول أولًا");
  return r.auth.uid;
};
const adminOnly = (r: CallableRequest) => {
  uid(r);
  if (r.auth?.token.admin !== true) throw new HttpsError("permission-denied", "للمسؤول فقط");
};
const shuffle = <T,>(a: T[]): T[] => {
  const b = [...a];
  for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; }
  return b;
};

// 1) إنشاء طلب: السعر يُحسب على الخادم دائمًا ولا يُقبل من العميل
export const createOrder = onCall(opts, async (r) => {
  const u = uid(r);
  const { bankId, code } = r.data as { bankId: string; code?: string };
  const bank = await db.doc(`banks/${bankId}`).get();
  if (!bank.exists || !bank.data()!.published) throw new HttpsError("not-found", "البنك غير متاح");
  if ((await db.doc(`entitlements/${u}_${bankId}`).get()).exists) throw new HttpsError("already-exists", "تملك هذا البنك مسبقًا");
  let amount: number = bank.data()!.price;
  let appliedCode = "";
  if (code) {
    const c = await db.doc(`codes/${String(code).toUpperCase()}`).get();
    if (!c.exists || !c.data()!.active) throw new HttpsError("invalid-argument", "كود الخصم غير صالح");
    amount = Math.round(amount * (1 - c.data()!.percent / 100) * 100) / 100;
    appliedCode = c.id;
  }
  const ref = db.collection("orders").doc();
  await ref.set({ uid: u, bankId, amount, code: appliedCode, status: "wait", txRef: "", createdAt: FieldValue.serverTimestamp() });
  return { orderId: ref.id, amount };
});

// 2) الطالب يرسل رقم عملية Orange Money (لا يفتح المحتوى، بل ينتظر مراجعة المسؤول)
export const submitPayment = onCall(opts, async (r) => {
  const u = uid(r);
  const { orderId, txRef } = r.data as { orderId: string; txRef: string };
  if (!/^[A-Za-z0-9-]{6,30}$/.test(txRef || "")) throw new HttpsError("invalid-argument", "رقم العملية غير صالح");
  const ref = db.doc(`orders/${orderId}`);
  const o = await ref.get();
  if (!o.exists || o.data()!.uid !== u || o.data()!.status !== "wait") throw new HttpsError("failed-precondition", "لا يمكن تعديل هذا الطلب");
  const dup = await db.collection("orders").where("txRef", "==", txRef).limit(1).get();
  if (!dup.empty) throw new HttpsError("already-exists", "رقم العملية مستخدم في طلب آخر");
  await ref.update({ txRef, status: "check" });
  return { ok: true };
});

// 3) المسؤول يؤكد الدفع بعد التحقق من وصول المبلغ في محفظته، فيُفتح البنك
export const confirmOrder = onCall(opts, async (r) => {
  adminOnly(r);
  const { orderId } = r.data as { orderId: string };
  await db.runTransaction(async (t) => {
    const ref = db.doc(`orders/${orderId}`);
    const o = await t.get(ref);
    if (!o.exists || o.data()!.status !== "check") throw new HttpsError("failed-precondition", "الطلب ليس قيد التحقق");
    const { uid: u, bankId } = o.data()!;
    t.update(ref, { status: "paid", confirmedAt: FieldValue.serverTimestamp() });
    t.set(db.doc(`entitlements/${u}_${bankId}`), { uid: u, bankId, orderId, at: FieldValue.serverTimestamp() });
  });
  return { ok: true };
});

export const rejectOrder = onCall(opts, async (r) => {
  adminOnly(r);
  const { orderId } = r.data as { orderId: string };
  await db.doc(`orders/${orderId}`).update({ status: "rej" });
  return { ok: true };
});

// 4) بدء اختبار: تُرسل الأسئلة بدون الإجابة الصحيحة، والخيارات بترتيب عشوائي
export const startAttempt = onCall(opts, async (r) => {
  const u = uid(r);
  const { bankId, kind, count, minutes, mode } = r.data as { bankId: string; kind: "free" | "full"; count: number; minutes?: number; mode: "practice" | "exam" };
  let q = db.collection(`banks/${bankId}/questions`) as FirebaseFirestore.Query;
  if (kind === "free") q = q.where("sample", "==", true);
  else if (!(await db.doc(`entitlements/${u}_${bankId}`).get()).exists) throw new HttpsError("permission-denied", "اشترِ البنك أولًا");
  const all = await q.get();
  const picked = shuffle(all.docs).slice(0, Math.max(1, Math.min(Number(count) || 10, kind === "free" ? 5 : 100)));
  const ref = db.collection("attempts").doc();
  await ref.set({
    uid: u, bankId, kind, mode, qids: picked.map((d) => d.id), done: false,
    endsAt: mode === "exam" ? Date.now() + (Math.min(Number(minutes) || 30, 240)) * 60000 : 0,
  });
  const questions = picked.map((d) => ({
    id: d.id, text: d.data().text,
    options: shuffle((d.data().options as string[]).map((t, i) => ({ i, t }))),
  }));
  return { attemptId: ref.id, questions, endsAt: mode === "exam" ? Date.now() + (Number(minutes) || 30) * 60000 : 0 };
});

// 5) وضع التدريب فقط: كشف صحة الإجابة والشرح لسؤال واحد
export const checkAnswer = onCall(opts, async (r) => {
  const u = uid(r);
  const { attemptId, qid, choice } = r.data as { attemptId: string; qid: string; choice: number };
  const a = (await db.doc(`attempts/${attemptId}`).get()).data();
  if (!a || a.uid !== u || a.mode !== "practice" || !a.qids.includes(qid)) throw new HttpsError("permission-denied", "غير مسموح");
  const q = (await db.doc(`banks/${a.bankId}/questions/${qid}`).get()).data()!;
  return { correct: q.correct === choice, right: q.correct, explanation: q.explanation || "" };
});

// 6) التصحيح على الخادم عند الإنهاء، ثم تظهر الإجابات الصحيحة
export const submitAttempt = onCall(opts, async (r) => {
  const u = uid(r);
  const { attemptId, answers } = r.data as { attemptId: string; answers: Record<string, number> };
  const ref = db.doc(`attempts/${attemptId}`);
  const a = (await ref.get()).data();
  if (!a || a.uid !== u) throw new HttpsError("permission-denied", "غير مسموح");
  if (a.done) throw new HttpsError("failed-precondition", "أُنهي هذا الاختبار مسبقًا");
  if (a.endsAt && Date.now() > a.endsAt + 20000) throw new HttpsError("deadline-exceeded", "انتهى وقت الاختبار");
  const items = [];
  let score = 0;
  for (const qid of a.qids as string[]) {
    const q = (await db.doc(`banks/${a.bankId}/questions/${qid}`).get()).data()!;
    const ok = answers?.[qid] === q.correct;
    if (ok) score++;
    items.push({ qid, text: q.text, ok, your: answers?.[qid] ?? null, right: q.correct, options: q.options, explanation: q.explanation || "" });
  }
  const res = db.collection("results").doc();
  await res.set({ uid: u, bankId: a.bankId, mode: a.mode, score, total: items.length, pct: Math.round((score / items.length) * 100), items, at: FieldValue.serverTimestamp() });
  await ref.update({ done: true });
  return { resultId: res.id, score, total: items.length };
});
