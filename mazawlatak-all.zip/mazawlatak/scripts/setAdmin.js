// الاستخدام: node scripts/setAdmin.js you@example.com   (مع ملف serviceAccount.json)
const admin = require("firebase-admin");
admin.initializeApp({ credential: admin.credential.cert(require("./serviceAccount.json")) });
admin.auth().getUserByEmail(process.argv[2])
  .then((u) => admin.auth().setCustomUserClaims(u.uid, { admin: true }))
  .then(() => { console.log("تم منح صلاحية المسؤول. سجّل الخروج والدخول مجددًا."); process.exit(0); })
  .catch((e) => { console.error(e.message); process.exit(1); });
